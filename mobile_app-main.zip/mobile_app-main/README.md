# mobile_app
 Image detection mobile application
